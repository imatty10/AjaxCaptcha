<?php
session_start();
if(isset($_POST) && count($_POST) > 0){
    $response = 1;
    if(empty($_SESSION['captcha_code']) || strcasecmp($_SESSION['captcha_code'], $_POST['captcha']) != 0)
    {
        $response = 0;
    }
    echo $response; exit;
}
?>
<html>
<head>
    <title>Contact us</title>
    <link href="style.css" type="text/css" rel="stylesheet">
		<script type="text/javascript">  
			 var before_loadtime = new Date().getTime();  
			 window.onload = Pageloadtime;  
			 function Pageloadtime() {  
				 var aftr_loadtime = new Date().getTime();  
				 // Time calculating in seconds  
				 pgloadtime = (aftr_loadtime - before_loadtime) / 100  
		  
				 document.getElementById("loadtime").innerHTML = "Response time is <font color='red'><b>" + pgloadtime + "</b></font> Seconds";  
			 }  
		</script>  
</head>
<body>
	<div class="container">
		<div class="sub-container">
			<h1>Thank you for submitting Text Captcha!!</h1>
			<div>  
				<span id="loadtime"></span>  	  
			</div> 
			<a href='src/index.html'>Proceed to image Captcha.</a>
		</div>
	</div>
</body>
</html>