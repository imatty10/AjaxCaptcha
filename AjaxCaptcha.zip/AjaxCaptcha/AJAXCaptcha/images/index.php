<?php
/********************************************************************************************************************
* Contact Form with Captcha using Ajax, Jquery and PHP
* This script is brought to you by Vasplus Programming Blog by whom all copyrights are reserved.
* Website: www.vasplus.info
* Email: vasplusblog@gmail.com or info@vasplus.info
* Please, this script must not be sold and do not remove this information from the top of this page.
*********************************************************************************************************************/
?>